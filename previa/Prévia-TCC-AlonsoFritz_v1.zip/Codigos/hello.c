/**
 * Arquivo: hello.c
 * Implementa: Solucao do Problema beecrowd 1000 "Hello
 * World"
 */

#include <stdio.h>

int main()
{
   printf("Hello World!\n");
   return 0;
}